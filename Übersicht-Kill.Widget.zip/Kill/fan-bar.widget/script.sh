#!/usr/bin/env bash

lFan="$(./kill/fan-bar.widget/osx-cpu-temp -f)"
cpuTemp="$(./kill/fan-bar.widget/osx-cpu-temp -c)"
echo $lFan 
echo " "$cpuTemp
