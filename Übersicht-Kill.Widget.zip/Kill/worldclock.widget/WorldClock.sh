#!/bin/sh
echo "Hanoi;`export TZ='Asia/Ho_Chi_Minh';date +'%-l:%M %p';unset TZ`"
echo "Tokyo;`export TZ='Asia/Tokyo';date +'%-l:%M %p';unset TZ`"
echo "Shanghai;`export TZ='Asia/Shanghai';date +'%-l:%M %p';unset TZ`"
echo "London;`export TZ='Europe/London';date +'%-l:%M %p';unset TZ`"
echo "Paris;`export TZ='Europe/Paris';date +'%-l:%M %p';unset TZ`"


